DiscordBot Maker is an Independant Software 
It helps you to make and manage your own bots !
------------------------
To use it, just press the shortcut and enjoy ^^
------------------------
Creator : IQ
Dirscord tag : IQ#9700
(text me on Discord for help)